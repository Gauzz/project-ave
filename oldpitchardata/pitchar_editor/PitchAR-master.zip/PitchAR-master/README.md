# PitchAR
An online AR creation tool.

url : /build/?token=jzXPgvSfhYMx7I3&edit=0

post url : https://pitchar.io/api/_search_media.php

"authtoken": "65oS4xbM6CVP",
            "type": "360",
            "video": "https://pitchar.io/uploads/video/1549538877.mp4",
            "thumbnail": "",
            "audio": "https://pitchar.io/uploads/audio/1549538877.mp3",
            "extension": "mp3",
            "project_name": "project name",
            "tags": "media,video,obj,thumbnail"


{
            "authtoken": "jzXPgvSfhYMx7I3",
            "type": "audio",
            "video": "",
            "thumbnail": "https://pitchar.io/uploads/videoThumbnail/1549526590.png",
            "audio": "https://pitchar.io/uploads/audio/1549526590.mp3",
            "extension": "mp3",
            "project_name": "project name",
            "tags": "media,video,obj,thumbnail"
        },

croppie doc : https://foliotek.github.io/Croppie/

https://www.w3schools.com/js/js_ajax_intro.asp

https://www.w3schools.com/js/js_json_intro.asp

https://www.w3schools.com/js/js_htmldom.asp

