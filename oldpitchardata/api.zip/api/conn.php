<?php
// $conn = mysql_connect("localhost","root","");
// $sql = mysql_select_db("project",$conn);


$conn=mysqli_connect("localhost","pitchar_project","111444777aaa@@@","pitchar_project");
//  if($conn==1){
//  	echo "connected";
//  }
//  else{
//  echo "error";
// }
 
?>