<?php 

	session_start();
	require_once 'Facebook/autoload.php';

	$FB= new \Facebook\Facebook([
		'app_id' => '185384345609885',
		'app_secret' => 'a7b8bdabed6dbefcf1a8f88b9b82c4e3',
		'default_graph_version' => 'v2.10'
	]);

	$helper= $FB->getRedirectLoginHelper();


?>